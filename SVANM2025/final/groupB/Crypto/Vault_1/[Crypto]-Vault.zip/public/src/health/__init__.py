"""Health-check app for liveness/readiness probes."""
