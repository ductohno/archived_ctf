"""Accounts app for custom User model and auth endpoints."""
