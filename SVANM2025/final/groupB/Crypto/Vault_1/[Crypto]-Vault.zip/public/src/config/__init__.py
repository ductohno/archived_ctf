"""Django project configuration package."""
