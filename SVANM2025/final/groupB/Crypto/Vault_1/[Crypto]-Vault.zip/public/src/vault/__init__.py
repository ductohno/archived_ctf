"""Vault application providing handshake and secret storage endpoints."""
