"""Shared utilities for logging, middleware, and cross-cutting concerns."""
