def hacked = param["hacked"]

if (hacked != null) {
    return "stop the hack"
} else {
    return null
}