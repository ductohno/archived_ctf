class VerificationError(Exception):
    """Raised when a cryptographic verification fails during the protocol."""

    pass
